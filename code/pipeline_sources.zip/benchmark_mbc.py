"""
Benchmark Morphogenetic Buds Clustering against common clustering algorithms.

Run:
    python benchmark_mbc.py
"""

from __future__ import annotations

import json
import time
import warnings
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from morphogenetic_buds_clustering import MorphogeneticBudsClustering
from sklearn.cluster import AgglomerativeClustering, DBSCAN, KMeans, SpectralClustering
from sklearn.datasets import (
    load_breast_cancer,
    load_digits,
    load_iris,
    load_wine,
    make_circles,
    make_moons,
)
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score, silhouette_score
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler


RANDOM_STATE = 13


def load_benchmark_datasets() -> list[tuple[str, np.ndarray, np.ndarray]]:
    iris = load_iris()
    wine = load_wine()
    cancer = load_breast_cancer()
    digits = load_digits()
    moons_x, moons_y = make_moons(n_samples=500, noise=0.07, random_state=RANDOM_STATE)
    circles_x, circles_y = make_circles(
        n_samples=500,
        factor=0.42,
        noise=0.045,
        random_state=RANDOM_STATE,
    )

    return [
        ("iris", iris.data, iris.target),
        ("wine", wine.data, wine.target),
        ("breast_cancer", cancer.data, cancer.target),
        ("digits_0_4", digits.data[digits.target < 5], digits.target[digits.target < 5]),
        ("two_moons", moons_x, moons_y),
        ("circles", circles_x, circles_y),
    ]


def preprocess(x: np.ndarray) -> np.ndarray:
    x = StandardScaler().fit_transform(x)
    if x.shape[1] > 8:
        keep = min(8, x.shape[0] - 1, x.shape[1])
        x = PCA(n_components=keep, random_state=RANDOM_STATE).fit_transform(x)
    return x


def run_algorithm(name: str, x: np.ndarray, n_clusters: int) -> np.ndarray:
    if name == "MBC":
        model = MorphogeneticBudsClustering(
            initial_buds=max(10, n_clusters * 5),
            steps=120,
            growth_rate=0.15,
            inhibition=0.045,
            apoptosis_mass=max(2.5, len(x) * 0.006),
            birth_quantile=0.88,
            organ_merge_radius=3.6,
            valley_ratio=0.18,
            tangent_alignment=0.35,
            max_bridge_void=0.46,
            target_clusters=n_clusters,
            compact_refinement_steps=18,
            compact_refinement_restarts=10,
            compact_refinement_dim_threshold=3,
            random_state=RANDOM_STATE,
        )
        return model.fit_predict(x)

    if name == "KMeans":
        return KMeans(n_clusters=n_clusters, n_init=20, random_state=RANDOM_STATE).fit_predict(x)

    if name == "GMM":
        return GaussianMixture(n_components=n_clusters, random_state=RANDOM_STATE).fit_predict(x)

    if name == "Agglomerative":
        return AgglomerativeClustering(n_clusters=n_clusters).fit_predict(x)

    if name == "Spectral":
        return SpectralClustering(
            n_clusters=n_clusters,
            affinity="nearest_neighbors",
            n_neighbors=min(12, len(x) - 1),
            random_state=RANDOM_STATE,
        ).fit_predict(x)

    if name == "DBSCAN":
        # A compact heuristic: estimate eps from median 5-neighbor distance.
        from sklearn.neighbors import NearestNeighbors

        k = min(6, len(x))
        distances = NearestNeighbors(n_neighbors=k).fit(x).kneighbors(x)[0][:, -1]
        eps = float(np.quantile(distances, 0.72))
        return DBSCAN(eps=eps, min_samples=max(4, x.shape[1] + 1)).fit_predict(x)

    raise ValueError(name)


def valid_silhouette(x: np.ndarray, labels: np.ndarray) -> float:
    unique = set(labels)
    if -1 in unique and len(unique) > 1:
        mask = labels != -1
        labels = labels[mask]
        x = x[mask]
    if len(set(labels)) < 2 or len(set(labels)) >= len(labels):
        return float("nan")
    return float(silhouette_score(x, labels))


def benchmark() -> pd.DataFrame:
    rows = []
    algorithms = ["MBC", "KMeans", "GMM", "Agglomerative", "Spectral", "DBSCAN"]
    for dataset_name, raw_x, y in load_benchmark_datasets():
        x = preprocess(raw_x)
        n_clusters = len(np.unique(y))
        for algo in algorithms:
            start = time.perf_counter()
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                labels = run_algorithm(algo, x, n_clusters)
            elapsed = time.perf_counter() - start
            rows.append(
                {
                    "dataset": dataset_name,
                    "algorithm": algo,
                    "clusters_found": len(set(labels)) - (1 if -1 in labels else 0),
                    "ari": adjusted_rand_score(y, labels),
                    "nmi": normalized_mutual_info_score(y, labels),
                    "silhouette": valid_silhouette(x, labels),
                    "seconds": elapsed,
                }
            )
    return pd.DataFrame(rows)


def save_summary(df: pd.DataFrame, out_dir: Path) -> None:
    csv_path = out_dir / "mbc_benchmark_results.csv"
    json_path = out_dir / "mbc_benchmark_results.json"
    md_path = out_dir / "mbc_benchmark_summary.md"
    png_path = out_dir / "mbc_benchmark_ari.png"

    df.to_csv(csv_path, index=False, encoding="utf-8-sig")
    json_path.write_text(df.to_json(orient="records", indent=2), encoding="utf-8")

    pivot = df.pivot(index="dataset", columns="algorithm", values="ari")
    ranking = df.groupby("algorithm")["ari"].mean().sort_values(ascending=False)

    lines = [
        "# MBC Benchmark Summary",
        "",
        "## Mean ARI Ranking",
        "",
        ranking.to_frame("mean_ari").round(4).to_markdown(),
        "",
        "## ARI by Dataset",
        "",
        pivot.round(4).to_markdown(),
        "",
        "## Notes",
        "",
        "- ARI and NMI use hidden labels only for evaluation.",
        "- Silhouette is label-only and does not use ground truth.",
        "- DBSCAN noise labels are kept for ARI/NMI; noise is removed only for silhouette.",
    ]
    md_path.write_text("\n".join(lines), encoding="utf-8")

    ax = pivot.plot(kind="bar", figsize=(11, 5.8), width=0.82)
    ax.set_title("Adjusted Rand Index on Benchmark Datasets")
    ax.set_ylabel("ARI")
    ax.set_ylim(-0.05, 1.02)
    ax.legend(loc="center left", bbox_to_anchor=(1.0, 0.5), frameon=False)
    ax.grid(axis="y", alpha=0.25)
    plt.tight_layout()
    plt.savefig(png_path, dpi=150)
    plt.close()

    print(f"Saved CSV: {csv_path}")
    print(f"Saved JSON: {json_path}")
    print(f"Saved Markdown: {md_path}")
    print(f"Saved plot: {png_path}")
    print()
    print("Mean ARI ranking:")
    print(ranking.round(4).to_string())


def main() -> None:
    out_dir = Path(__file__).resolve().parent
    df = benchmark()
    save_summary(df, out_dir)


if __name__ == "__main__":
    main()
